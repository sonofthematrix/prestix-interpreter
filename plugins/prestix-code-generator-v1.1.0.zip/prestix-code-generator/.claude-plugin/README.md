# Prestix Code Generator — Claude Plugin

AI-powered code generation for ZenStack entities, APIs, components, and infrastructure.

## What This Plugin Does

Generates complete CRUD interfaces for your ZenStack entities:

```
/generate User --all
```

Creates:
- ✅ API endpoints with auth and validation
- ✅ React components (forms, tables, cards)
- ✅ React hooks for data fetching
- ✅ TypeScript type definitions
- ✅ Navigation configuration

## Plugin Version

**v1.1.0** — Includes fully functional MCP server with 8 tools for schema analysis, code generation, validation, navigation generation, plugin management, and settings control.

## Quick Start

### Available Commands

| Command | Description |
|---------|-------------|
| `/analyze-schema` | Analyze your ZenStack schema |
| `/generate <Entity> --all` | Generate full CRUD for an entity |
| `/validate-schema` | Validate schema syntax |
| `/sync-state` | Sync app state with patterns |
| `/generate-navigation` | Generate route/navigation config |

### MCP Server Tools

The plugin includes a fully compiled MCP server (`mcp/zenstack-generator/dist/index.js`) with these tools:

| Tool | Description |
|------|-------------|
| `zenstack_analyze_schema` | Parse schema, list entities with fields and policies |
| `zenstack_list_entities` | Quick list of all entity names |
| `zenstack_validate_schema` | Validate schema for errors and warnings |
| `zenstack_generate_entity` | Run code generation for an entity |
| `zenstack_sync_state` | Sync app state with generation templates |
| `zenstack_generate_navigation` | Generate routes.ts and sidebar.ts |
| `zenstack_get_plugin_status` | Check plugin health and project setup |
| `zenstack_get_settings` | View current plugin settings |
| `zenstack_update_setting` | Update a plugin setting |
| `zenstack_run_diagnostics` | Full diagnostic health check |

## Plugin Structure

```
prestix-code-generator/
├── .claude-plugin/
│   ├── plugin.json              # Plugin manifest (v1.1.0)
│   ├── hooks/
│   │   ├── on-init.ts           # Plugin initialization
│   │   └── on-chat-message.ts   # Chat message handling & management
│   └── adapter/
│       └── plugin-adapter.ts    # Bridge to Prestix plugin system
├── skills/
│   ├── generate/SKILL.md
│   ├── analyze-schema/SKILL.md
│   ├── sync-state/SKILL.md
│   ├── generate-navigation/SKILL.md   ← New in v1.1.0
│   └── validate-schema/SKILL.md
└── mcp/
    └── zenstack-generator/
        ├── package.json
        └── dist/
            └── index.js         ← Pre-compiled, no npm install needed
```

## Team Sharing

The plugin is packaged as a standalone directory. To share with your team:

1. Copy the `prestix-code-generator/` folder to your shared location
2. Each team member installs via Cowork: **Plugins → Install from folder**
3. Point to the `prestix-code-generator/` directory

The MCP server is pre-compiled — no `npm install` required on team machines.

## Requirements

- Node.js 18+ (for MCP server)
- Cowork with plugin support
- ZenStack project with `zenstack.zmodel` in project root

## Changelog

### v1.1.0
- Added compiled MCP server with 10 tools for full plugin management
- Fixed: Added missing `skills/generate-navigation/SKILL.md`
- Fixed: All hook files now present (`on-chat-message.ts`)
- Fixed: Management page no longer crashes on load
- Added: Settings persistence via `.claude-plugin-settings.json`
- Added: Inline navigation generation (works without external generator scripts)

### v1.0.0
- Initial Claude plugin release
